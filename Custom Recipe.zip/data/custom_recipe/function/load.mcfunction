tellraw @a [{"text":"The custom recipes have been ","color":"gray"},{"text":"successfully","color":"green"},{"text":" loaded!","color":"gray"}]
